"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import Image from "next/image"
import { cn } from "@/lib/utils"
import {
  LayoutDashboard,
  ClipboardList,
  Users,
  PawPrint,
  FileHeart,
  Syringe,
  FileText,
  Pill,
  Calendar,
  Scissors,
  MessageCircle,
  Settings,
  ChevronLeft,
  ChevronRight,
  Menu,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"

const menuItems = [
  { href: "/", label: "Dashboard", icon: LayoutDashboard },
  { href: "/operaciones", label: "Operaciones", icon: ClipboardList },
  { href: "/clientes", label: "Clientes", icon: Users },
  { href: "/mascotas", label: "Mascotas", icon: PawPrint },
  { href: "/historial", label: "Historial Clínico", icon: FileHeart },
  { href: "/vacunas", label: "Vacunas", icon: Syringe },
  { href: "/estudios", label: "Estudios y Archivos", icon: FileText },
  { href: "/tratamientos", label: "Tratamientos", icon: Pill },
  { href: "/turnos", label: "Turnos", icon: Calendar },
  { href: "/cirugias", label: "Cirugías", icon: Scissors },
  { href: "/recordatorios", label: "Recordatorios WhatsApp", icon: MessageCircle },
  { href: "/configuracion", label: "Configuración", icon: Settings },
]

function SidebarContent({ collapsed, onToggle }: { collapsed: boolean; onToggle?: () => void }) {
  const pathname = usePathname()
  
  return (
    <div className="flex h-full flex-col bg-sidebar text-sidebar-foreground">
      {/* Logo */}
      <div className={cn(
        "flex items-center border-b border-sidebar-border px-4 py-4",
        collapsed ? "justify-center" : "gap-3"
      )}>
        <Image
          src="/logo-gross.png"
          alt="Agroveterinaria Gross"
          width={collapsed ? 40 : 50}
          height={collapsed ? 40 : 50}
          className="object-contain"
        />
        {!collapsed && (
          <div className="flex flex-col">
            <span className="text-xs font-medium text-sidebar-foreground/70">Agroveterinaria</span>
            <span className="text-lg font-bold tracking-tight">GROSS</span>
          </div>
        )}
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto sidebar-scrollbar px-2 py-4">
        <ul className="space-y-1">
          {menuItems.map((item) => {
            const isActive = pathname === item.href
            return (
              <li key={item.href}>
                <Link
                  href={item.href}
                  className={cn(
                    "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
                    collapsed && "justify-center px-2",
                    isActive
                      ? "bg-sidebar-accent text-sidebar-accent-foreground"
                      : "text-sidebar-foreground/80 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground"
                  )}
                  title={collapsed ? item.label : undefined}
                >
                  <item.icon className={cn("h-5 w-5 shrink-0", isActive && "text-secondary")} />
                  {!collapsed && <span>{item.label}</span>}
                </Link>
              </li>
            )
          })}
        </ul>
      </nav>

      {/* Collapse Toggle */}
      {onToggle && (
        <div className="border-t border-sidebar-border p-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={onToggle}
            className="w-full justify-center text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-foreground"
          >
            {collapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
          </Button>
        </div>
      )}
    </div>
  )
}

export function Sidebar() {
  const [collapsed, setCollapsed] = useState(false)

  return (
    <>
      {/* Desktop Sidebar */}
      <aside
        className={cn(
          "hidden lg:flex flex-col border-r border-sidebar-border bg-sidebar transition-all duration-300",
          collapsed ? "w-[70px]" : "w-[260px]"
        )}
      >
        <SidebarContent collapsed={collapsed} onToggle={() => setCollapsed(!collapsed)} />
      </aside>

      {/* Mobile Sidebar */}
      <Sheet>
        <SheetTrigger asChild>
          <Button
            variant="ghost"
            size="icon"
            className="lg:hidden fixed top-3 left-3 z-50 bg-primary text-primary-foreground hover:bg-primary/90"
          >
            <Menu className="h-5 w-5" />
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="w-[260px] p-0 bg-sidebar border-sidebar-border">
          <SidebarContent collapsed={false} />
        </SheetContent>
      </Sheet>
    </>
  )
}
