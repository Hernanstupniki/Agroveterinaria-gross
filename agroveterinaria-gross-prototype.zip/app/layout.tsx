import type { Metadata, Viewport } from 'next'
import { Geist, Geist_Mono } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import './globals.css'

const _geist = Geist({ subsets: ["latin"] });
const _geistMono = Geist_Mono({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: 'Agroveterinaria Gross - Sistema de Gestión Clínica',
  description: 'Sistema de gestión clínica veterinaria para Agroveterinaria Gross. Historial clínico, vacunas, turnos, cirugías y más.',
  generator: 'v0.app',
  icons: {
    icon: '/logo-gross.png',
    apple: '/logo-gross.png',
  },
}

export const viewport: Viewport = {
  themeColor: '#B3007A',
  width: 'device-width',
  initialScale: 1,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="es" className="bg-background">
      <body className="font-sans antialiased">
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
